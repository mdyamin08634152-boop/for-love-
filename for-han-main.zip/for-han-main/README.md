# happy-valentine-day

Hey Couples out there here the Valentine's surprise for your partner
just tap or click on the heart and the audio will start playing

Live link: https://gevendra2004.github.io/happy-valentine-day/

* It has both male and female audio separately
